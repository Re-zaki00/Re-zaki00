AUForm::AUForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AUForm)
{
    ui->setupUi(this);

    // Connect the clicked signal of the AdminLogin button to the slot function
    connect(ui->AdminLogin, &QPushButton::clicked, this, &AUForm::openAdminLoginForm);
    // Connect the clicked signal of the UserLogin button to the slot function
    connect(ui->UserLogin, &QPushButton::clicked, this, &AUForm::openUserLoginForm);
}

AUForm::~AUForm()
{
    delete ui;
}

void AUForm::openAdminLoginForm()
{
    // Create an instance of the AdminLoginForm
    AdminLoginForm* admin_login_form = new AdminLoginForm(this);

    // Show the AdminLoginForm
    admin_login_form->show();
}
void AUForm::openUserLoginForm()
{
    // Create an instance of the UserLoginForm
    UserLoginForm* user_login_form = new UserLoginForm(this);

    // Show the UserLoginForm
    user_login_form->show();
}
