#ifndef AUFORM_H
#define AUFORM_H

#include <QWidget>

namespace Ui {
class AUForm;
}

class AUForm : public QWidget
{
    Q_OBJECT

public:
    explicit AUForm(QWidget *parent = nullptr);
    ~AUForm();

private slots:
    void on_AdminLogin_clicked();

private:
    Ui::AUForm *ui;
};

#endif // AUFORM_H
