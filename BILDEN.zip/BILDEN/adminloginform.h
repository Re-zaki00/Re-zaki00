#ifndef ADMINLOGINFORM_H
#define ADMINLOGINFORM_H

#include <QWidget>

namespace Ui {
class AdminLoginForm;
}

class AdminLoginForm : public QWidget
{
    Q_OBJECT

public:
    explicit AdminLoginForm(QWidget *parent = nullptr);
    ~AdminLoginForm();

private:
    Ui::AdminLoginForm *ui;
};

#endif // ADMINLOGINFORM_H
