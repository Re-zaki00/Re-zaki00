# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'Userlogin.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QWidget)

class Ui_UserLoginForm(object):
    def setupUi(self, UserLoginForm):
        if not UserLoginForm.objectName():
            UserLoginForm.setObjectName(u"UserLoginForm")
        UserLoginForm.resize(1071, 653)
        UserLoginForm.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox = QGroupBox(UserLoginForm)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(80, 90, 921, 441))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet(u"background-color: rgb(91, 15, 255);\n"
"color: rgb(255, 255, 255);")
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(90, 140, 121, 61))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setItalic(True)
        self.label.setFont(font1)
        self.label.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_2 = QLabel(self.groupBox)
        self.label_2.setObjectName(u"label_2")
        self.label_2.setGeometry(QRect(90, 240, 121, 61))
        font2 = QFont()
        font2.setBold(True)
        font2.setItalic(True)
        self.label_2.setFont(font2)
        self.label_2.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_2.setAlignment(Qt.AlignCenter)
        self.ULogin = QPushButton(self.groupBox)
        self.ULogin.setObjectName(u"ULogin")
        self.ULogin.setGeometry(QRect(410, 370, 121, 51))
        self.ULogin.setFont(font1)
        self.ULogin.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.URoll = QLineEdit(self.groupBox)
        self.URoll.setObjectName(u"URoll")
        self.URoll.setGeometry(QRect(240, 140, 621, 61))
        self.URoll.setStyleSheet(u"font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);\n"
"background-color: rgb(0, 0, 0);")
        self.Upass = QLineEdit(self.groupBox)
        self.Upass.setObjectName(u"Upass")
        self.Upass.setGeometry(QRect(240, 240, 621, 61))
        self.Upass.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")

        self.retranslateUi(UserLoginForm)

        QMetaObject.connectSlotsByName(UserLoginForm)
    # setupUi

    def retranslateUi(self, UserLoginForm):
        UserLoginForm.setWindowTitle(QCoreApplication.translate("UserLoginForm", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("UserLoginForm", u"Bilden", None))
        self.label.setText(QCoreApplication.translate("UserLoginForm", u"Roll#", None))
        self.label_2.setText(QCoreApplication.translate("UserLoginForm", u"Password :", None))
        self.ULogin.setText(QCoreApplication.translate("UserLoginForm", u"Login", None))
    # retranslateUi

