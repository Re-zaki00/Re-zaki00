# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'auform.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QPushButton, QSizePolicy,
    QWidget)

class Ui_AUForm(object):
    def setupUi(self, AUForm):
        if not AUForm.objectName():
            AUForm.setObjectName(u"AUForm")
        AUForm.resize(1071, 651)
        AUForm.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox = QGroupBox(AUForm)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(10, 10, 1051, 631))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet(u"background-color: rgb(91, 15, 255);\n"
"color: rgb(255, 255, 255);")
        self.AdminLogin = QPushButton(self.groupBox)
        self.AdminLogin.setObjectName(u"AdminLogin")
        self.AdminLogin.setGeometry(QRect(310, 160, 461, 81))
        font1 = QFont()
        font1.setPointSize(10)
        font1.setBold(True)
        font1.setItalic(True)
        self.AdminLogin.setFont(font1)
        self.AdminLogin.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.UserLogin = QPushButton(self.groupBox)
        self.UserLogin.setObjectName(u"UserLogin")
        self.UserLogin.setGeometry(QRect(310, 350, 461, 81))
        self.UserLogin.setFont(font1)
        self.UserLogin.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")

        self.retranslateUi(AUForm)

        QMetaObject.connectSlotsByName(AUForm)
    # setupUi

    def retranslateUi(self, AUForm):
        AUForm.setWindowTitle(QCoreApplication.translate("AUForm", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("AUForm", u"Bilden", None))
        self.AdminLogin.setText(QCoreApplication.translate("AUForm", u"Admin Login", None))
        self.UserLogin.setText(QCoreApplication.translate("AUForm", u"User Login", None))
    # retranslateUi

