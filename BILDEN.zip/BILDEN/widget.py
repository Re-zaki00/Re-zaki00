import os
from pathlib import Path
import sys
from PySide6.QtWidgets import QApplication, QWidget, QPushButton, QLineEdit, QMessageBox
from PySide6.QtCore import QFile
from PySide6.QtUiTools import QUiLoader
from PySide6.QtCore import Slot, QTimer
from sendgrid import SendGridAPIClient
from sendgrid.helpers.mail import Mail



class Start(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_ui()
        self.timer = QTimer()
        self.timer.setSingleShot(True)
        self.timer.timeout.connect(self.show_AUForm)
        self.timer.start(2000)  # Delay in milliseconds

    @Slot()
    def show_AUForm(self):
        if not hasattr(self, 'au_form') or not self.au_form:
            self.au_form = AUForm()
        self.au_form.show()
        self.hide()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "Start.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()


class UserLoginForm(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.ui = None
        self.main_window = None
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "Userlogin.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()
        self.ui = loader.load(ui_file)

        ULogin_button = self.findChild(QPushButton, "ULogin")
        if ULogin_button:
            ULogin_button.clicked.connect(self.perform_login)  # Connect to perform_login slot
        else:
            print("ULogin button not found.")

    @Slot()
    def perform_login(self):
        roll_line_edit = self.findChild(QLineEdit, "URoll")
        pass_line_edit = self.findChild(QLineEdit, "Upass")

        roll_number = roll_line_edit.text()
        password = pass_line_edit.text()

        if roll_number == "0001" and password == "Teacher":
            if not self.main_window:
                self.main_window = MainWindow()
            self.main_window.show()
            self.hide()
        elif roll_number == "0001" and password == "Student":
            if not self.main_window:
                self.main_window = SForm()
            self.main_window.show()
            self.hide()
        else:
            QMessageBox.critical(self, "Error", "Invalid Roll Number or Password")

class AdminWindow(QWidget):
    def __init__(self):
        super().__init__()
        self.View_report = None
        self.aregister = None
        self.admin_login_form = None  # Add this line
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "adminwindow.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

        view_reports_button = self.findChild(QPushButton, "Viewreports")
        if view_reports_button:
            view_reports_button.clicked.connect(self.show_View_report)
        else:
            print("View_reports button not found.")

        aregister_button = self.findChild(QPushButton, "ARegister")
        if aregister_button:
            aregister_button.clicked.connect(self.show_Register)
        else:
            print("aregister button not found.")

        back_button = self.findChild(QPushButton, "Back")
        if back_button:
            back_button.clicked.connect(self.show_admin_login)
        else:
            print("Back button not found.")

    @Slot()
    def show_View_report(self):
        if not self.View_report:
            self.View_report = Report()
        self.View_report.show()

    @Slot()
    def show_Register(self):
        if not self.aregister:
            self.aregister = Register()
        self.aregister.show()

    @Slot()
    def show_admin_login(self):
        if not self.admin_login_form:
            self.admin_login_form = AdminLoginForm()
        self.admin_login_form.show()
        self.hide()

class Report(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "viewreports.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()


class Register(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.admin_window = None
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "Register.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

        confirm_button = self.findChild(QPushButton, "RConfirm")
        if confirm_button:
            confirm_button.clicked.connect(self.send_email)  # Connect to send_email slot
        else:
            print("Confirm button not found.")

        back_button = self.findChild(QPushButton, "Back")
        if back_button:
            back_button.clicked.connect(self.show_admin_window)  # Connect to show_admin_window slot
        else:
            print("Back button not found.")

    @Slot()
    def send_email(self):
        name_line_edit = self.findChild(QLineEdit, "RName")
        email_line_edit = self.findChild(QLineEdit, "REmail")
        password_line_edit = self.findChild(QLineEdit, "RPass")

        name = name_line_edit.text()
        email = email_line_edit.text()
        password = password_line_edit.text()

        if name and email and password:
            subject = "Registration Confirmation"
            message = f"Dear {name},\n\nThank you for registering. Your password is: {password}"

            # Construct email
            email_message = Mail(
                from_email="zakiakram00@gmail.com",
                to_emails=email,
                subject=subject,
                plain_text_content=message
            )

            # Send email
            try:
                sg = SendGridAPIClient(api_key='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')
                response = sg.send(email_message)

                if response.status_code == 202:
                        QMessageBox.information(self, "Success", "Registration confirmation email sent!")
                else:
                        QMessageBox.critical(self, "Error", "Failed to send email.")
            except Exception as e:
                        QMessageBox.critical(self, "Error", f"Failed to send email: {str(e)}")
        else:
            QMessageBox.critical(self, "Error", "Please enter all fields.")

    @Slot()
    def show_admin_window(self):
        if not self.admin_window:
            self.admin_window = AdminWindow()
        self.admin_window.show()
        self.hide()

class AUForm(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.user_login_form = None
        self.admin_login_form = None  # Add this line
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "auform.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

        admin_login_button = self.findChild(QPushButton, "AdminLogin")
        if admin_login_button:
            admin_login_button.clicked.connect(self.show_AdminLogin)
        else:
            print("AdminLogin button not found.")

        user_login_button = self.findChild(QPushButton, "UserLogin")
        if user_login_button:
            user_login_button.clicked.connect(self.show_UserLogin)
        else:
            print("UserLogin button not found.")

    @Slot()
    def show_AdminLogin(self):
        if not self.admin_login_form:
            self.admin_login_form = AdminLoginForm()
        self.admin_login_form.show()
        self.hide()

    @Slot()
    def show_UserLogin(self):
        if not self.user_login_form:
            self.user_login_form = UserLoginForm()
        self.user_login_form.show()
        self.hide()

class SForm(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.submit_form = None
        self.cancel_form = None
        self.user_login_form = None
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "Userform.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

        submit_form_button = self.findChild(QPushButton, "Submit")
        submit_form_button.clicked.connect(self.show_Submit)
        cancel_form_button = self.findChild(QPushButton, "Cancel")
        cancel_form_button.clicked.connect(self.show_Cancel)

    @Slot()
    def show_Submit(self):
        QMessageBox.information(self, "Success", "Form Submitted")

    @Slot()
    def show_Cancel(self):
        if not self.user_login_form:
            self.user_login_form = UserLoginForm()
        self.user_login_form.show()
        self.hide()

class AdminLoginForm(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.admin_window = None
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "adminloginform.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()

        confirm_button = self.findChild(QPushButton, "Confirm")
        if confirm_button:
            confirm_button.clicked.connect(self.show_AdminWindow)
        else:
            print("Confirm button not found.")

    @Slot()
    def show_AdminWindow(self):
        id_line_edit = self.findChild(QLineEdit, "ID")
        password_line_edit = self.findChild(QLineEdit, "Password")

        if id_line_edit.text() == "UA12" and password_line_edit.text() == "Riphah2X3":
            if not self.admin_window:
                self.admin_window = AdminWindow()
            self.admin_window.show()
            self.hide()
        else:
            QMessageBox.critical(self, "Error", "Invalid ID or Password")


class MainWindow(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.load_ui()

    def load_ui(self):
        loader = QUiLoader()
        path = Path(__file__).resolve().parent / "mainwindow.ui"
        ui_file = QFile(path)
        ui_file.open(QFile.ReadOnly)
        loader.load(ui_file, self)
        ui_file.close()


if __name__ == "__main__":
    app = QApplication(sys.argv)
    Swidget = Start()
    '''
    Rwidget = Register()
    Fwidget = Report()
    Mwidget = MainWindow()
    SEwidget = SForm()
    Auwidget = AUForm()
    AWwidget = AdminWindow()
    Adwidget = AdminLoginForm()
    Mwidget.show()
    SEwidget.show()
    Rwidget.show()
    Fwidget.show()
    AWwidget.show()
    Adwidget.show()
    Auwidget.show()
    '''
    Swidget.show()
    sys.exit(app.exec())
