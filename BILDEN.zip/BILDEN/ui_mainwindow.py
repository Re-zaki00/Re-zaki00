# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'mainwindow.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QAbstractButton, QApplication, QComboBox, QDialogButtonBox,
    QFontComboBox, QPlainTextEdit, QRadioButton, QScrollArea,
    QScrollBar, QSizePolicy, QTabWidget, QWidget)

class Ui_MainWindow(object):
    def setupUi(self, MainWindow):
        if not MainWindow.objectName():
            MainWindow.setObjectName(u"MainWindow")
        MainWindow.resize(1071, 653)
        MainWindow.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.tabWidget = QTabWidget(MainWindow)
        self.tabWidget.setObjectName(u"tabWidget")
        self.tabWidget.setGeometry(QRect(0, 0, 1071, 80))
        self.tabWidget.setStyleSheet(u"background-color: rgb(0, 170, 255);\n"
"color: rgb(0, 0, 0);")
        self.tab = QWidget()
        self.tab.setObjectName(u"tab")
        self.tabWidget.addTab(self.tab, "")
        self.tab_2 = QWidget()
        self.tab_2.setObjectName(u"tab_2")
        self.buttonBox = QDialogButtonBox(self.tab_2)
        self.buttonBox.setObjectName(u"buttonBox")
        self.buttonBox.setGeometry(QRect(880, 0, 167, 51))
        self.buttonBox.setStandardButtons(QDialogButtonBox.Cancel|QDialogButtonBox.Ok)
        self.comboBox = QComboBox(self.tab_2)
        self.comboBox.addItem("")
        self.comboBox.setObjectName(u"comboBox")
        self.comboBox.setGeometry(QRect(0, 10, 61, 31))
        self.comboBox_2 = QComboBox(self.tab_2)
        self.comboBox_2.addItem("")
        self.comboBox_2.setObjectName(u"comboBox_2")
        self.comboBox_2.setGeometry(QRect(60, 10, 61, 31))
        self.comboBox_3 = QComboBox(self.tab_2)
        self.comboBox_3.addItem("")
        self.comboBox_3.setObjectName(u"comboBox_3")
        self.comboBox_3.setGeometry(QRect(120, 10, 71, 31))
        self.comboBox_4 = QComboBox(self.tab_2)
        self.comboBox_4.addItem("")
        self.comboBox_4.setObjectName(u"comboBox_4")
        self.comboBox_4.setGeometry(QRect(190, 10, 101, 31))
        self.fontComboBox = QFontComboBox(self.tab_2)
        self.fontComboBox.setObjectName(u"fontComboBox")
        self.fontComboBox.setGeometry(QRect(290, 10, 261, 31))
        self.radioButton = QRadioButton(self.tab_2)
        self.radioButton.setObjectName(u"radioButton")
        self.radioButton.setGeometry(QRect(750, 5, 121, 41))
        self.radioButton.setStyleSheet(u"")
        self.tabWidget.addTab(self.tab_2, "")
        self.scrollArea = QScrollArea(MainWindow)
        self.scrollArea.setObjectName(u"scrollArea")
        self.scrollArea.setGeometry(QRect(0, 80, 1071, 571))
        self.scrollArea.setWidgetResizable(True)
        self.scrollAreaWidgetContents = QWidget()
        self.scrollAreaWidgetContents.setObjectName(u"scrollAreaWidgetContents")
        self.scrollAreaWidgetContents.setGeometry(QRect(0, 0, 1069, 569))
        self.plainTextEdit = QPlainTextEdit(self.scrollAreaWidgetContents)
        self.plainTextEdit.setObjectName(u"plainTextEdit")
        self.plainTextEdit.setGeometry(QRect(0, 0, 1071, 571))
        self.plainTextEdit.setStyleSheet(u"background-color: rgb(255, 255, 255);\n"
"color: rgb(0, 0, 0);\n"
"selection-color: rgb(255, 255, 0);\n"
"selection-background-color: rgb(85, 0, 255);")
        self.verticalScrollBar = QScrollBar(self.scrollAreaWidgetContents)
        self.verticalScrollBar.setObjectName(u"verticalScrollBar")
        self.verticalScrollBar.setGeometry(QRect(1050, 0, 21, 551))
        self.verticalScrollBar.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.50661, y1:0.017, x2:0.511695, y2:0.966, stop:1 rgba(101, 101, 102, 255));")
        self.verticalScrollBar.setOrientation(Qt.Vertical)
        self.horizontalScrollBar = QScrollBar(self.scrollAreaWidgetContents)
        self.horizontalScrollBar.setObjectName(u"horizontalScrollBar")
        self.horizontalScrollBar.setGeometry(QRect(-1, 549, 1071, 21))
        self.horizontalScrollBar.setStyleSheet(u"background-color: qlineargradient(spread:pad, x1:0.50661, y1:0.017, x2:0.511695, y2:0.966, stop:1 rgba(101, 101, 102, 255));\n"
"background-color: rgb(170, 85, 127);\n"
"color: rgb(0, 0, 0);")
        self.horizontalScrollBar.setOrientation(Qt.Horizontal)
        self.scrollArea.setWidget(self.scrollAreaWidgetContents)

        self.retranslateUi(MainWindow)

        self.tabWidget.setCurrentIndex(1)


        QMetaObject.connectSlotsByName(MainWindow)
    # setupUi

    def retranslateUi(self, MainWindow):
        MainWindow.setWindowTitle(QCoreApplication.translate("MainWindow", u"Form", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab), QCoreApplication.translate("MainWindow", u"Tab 1", None))
        self.comboBox.setItemText(0, QCoreApplication.translate("MainWindow", u"File", None))

        self.comboBox_2.setItemText(0, QCoreApplication.translate("MainWindow", u"Edit", None))

        self.comboBox_3.setItemText(0, QCoreApplication.translate("MainWindow", u"View", None))

        self.comboBox_4.setItemText(0, QCoreApplication.translate("MainWindow", u"Templates", None))

        self.radioButton.setText(QCoreApplication.translate("MainWindow", u"Dark Mode", None))
        self.tabWidget.setTabText(self.tabWidget.indexOf(self.tab_2), QCoreApplication.translate("MainWindow", u"Tab 2", None))
    # retranslateUi

