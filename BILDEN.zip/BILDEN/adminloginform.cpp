#include "adminloginform.h"
#include "ui_adminloginform.h"

AdminLoginForm::AdminLoginForm(QWidget *parent) :
    QWidget(parent),
    ui(new Ui::AdminLoginForm)
{
    ui->setupUi(this);

    // Connect the clicked signal of the Confirm button to the slot function
    connect(ui->Confirm, &QPushButton::clicked, this, &AdminLoginForm::openAdminWindow);
}

AdminLoginForm::~AdminLoginForm()
{
    delete ui;
}

void AdminLoginForm::openAdminWindow()
{
    // Create an instance of the AdminWindow
    AdminWindow* admin_window = new AdminWindow(this);

    // Show the AdminWindow
    admin_window->show();
}
