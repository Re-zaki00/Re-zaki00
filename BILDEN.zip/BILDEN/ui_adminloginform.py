# -*- coding: utf-8 -*-

################################################################################
## Form generated from reading UI file 'adminloginform.ui'
##
## Created by: Qt User Interface Compiler version 6.4.1
##
## WARNING! All changes made in this file will be lost when recompiling UI file!
################################################################################

from PySide6.QtCore import (QCoreApplication, QDate, QDateTime, QLocale,
    QMetaObject, QObject, QPoint, QRect,
    QSize, QTime, QUrl, Qt)
from PySide6.QtGui import (QBrush, QColor, QConicalGradient, QCursor,
    QFont, QFontDatabase, QGradient, QIcon,
    QImage, QKeySequence, QLinearGradient, QPainter,
    QPalette, QPixmap, QRadialGradient, QTransform)
from PySide6.QtWidgets import (QApplication, QGroupBox, QLabel, QLineEdit,
    QPushButton, QSizePolicy, QWidget)

class Ui_AdminLoginForm(object):
    def setupUi(self, AdminLoginForm):
        if not AdminLoginForm.objectName():
            AdminLoginForm.setObjectName(u"AdminLoginForm")
        AdminLoginForm.resize(1071, 651)
        AdminLoginForm.setStyleSheet(u"background-color: rgb(0, 0, 0);")
        self.groupBox = QGroupBox(AdminLoginForm)
        self.groupBox.setObjectName(u"groupBox")
        self.groupBox.setGeometry(QRect(10, 10, 1051, 631))
        font = QFont()
        font.setPointSize(11)
        font.setBold(True)
        font.setItalic(True)
        self.groupBox.setFont(font)
        self.groupBox.setStyleSheet(u"background-color: rgb(91, 15, 255);\n"
"color: rgb(255, 255, 255);\n"
"gridline-color: rgb(0, 0, 0);")
        self.label = QLabel(self.groupBox)
        self.label.setObjectName(u"label")
        self.label.setGeometry(QRect(10, 50, 1031, 61))
        font1 = QFont()
        font1.setPointSize(11)
        font1.setBold(True)
        font1.setItalic(True)
        font1.setUnderline(True)
        self.label.setFont(font1)
        self.label.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label.setAlignment(Qt.AlignCenter)
        self.label_3 = QLabel(self.groupBox)
        self.label_3.setObjectName(u"label_3")
        self.label_3.setGeometry(QRect(110, 300, 161, 51))
        self.label_3.setFont(font)
        self.label_3.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_3.setAlignment(Qt.AlignCenter)
        self.ID = QLineEdit(self.groupBox)
        self.ID.setObjectName(u"ID")
        self.ID.setGeometry(QRect(300, 160, 391, 51))
        self.ID.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.Password = QLineEdit(self.groupBox)
        self.Password.setObjectName(u"Password")
        self.Password.setGeometry(QRect(300, 300, 391, 51))
        self.Password.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"font: 700 12pt \"Segoe UI\";\n"
"color: rgb(255, 255, 255);")
        self.Confirm = QPushButton(self.groupBox)
        self.Confirm.setObjectName(u"Confirm")
        self.Confirm.setGeometry(QRect(720, 460, 141, 61))
        self.Confirm.setFont(font)
        self.Confirm.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_4 = QLabel(self.groupBox)
        self.label_4.setObjectName(u"label_4")
        self.label_4.setGeometry(QRect(110, 160, 161, 51))
        self.label_4.setFont(font)
        self.label_4.setStyleSheet(u"background-color: rgb(0, 0, 0);\n"
"color: rgb(255, 255, 255);")
        self.label_4.setAlignment(Qt.AlignCenter)

        self.retranslateUi(AdminLoginForm)

        QMetaObject.connectSlotsByName(AdminLoginForm)
    # setupUi

    def retranslateUi(self, AdminLoginForm):
        AdminLoginForm.setWindowTitle(QCoreApplication.translate("AdminLoginForm", u"Form", None))
        self.groupBox.setTitle(QCoreApplication.translate("AdminLoginForm", u"Bilden", None))
        self.label.setText(QCoreApplication.translate("AdminLoginForm", u"Admin Login", None))
        self.label_3.setText(QCoreApplication.translate("AdminLoginForm", u"Password :", None))
        self.Confirm.setText(QCoreApplication.translate("AdminLoginForm", u"Confirm", None))
        self.label_4.setText(QCoreApplication.translate("AdminLoginForm", u"ID", None))
    # retranslateUi

